## @package onnx
# Module caffe2.python.onnx.error




class BaseException(Exception): pass
class Unsupported(BaseException): pass
