## @package predictor_constants
# Module caffe2.python.predictor_constants




import caffe2.proto.predictor_consts_pb2 as predictor_consts

predictor_constants = predictor_consts.PredictorConsts()
