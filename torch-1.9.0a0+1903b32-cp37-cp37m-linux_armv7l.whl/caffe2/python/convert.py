## @package workspace
# Module caffe2.python.workspace





